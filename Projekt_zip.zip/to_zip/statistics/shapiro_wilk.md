|    | Station            | Parameter     |   Shapiro-Wilk Statistic |   P-value | Normal Distribution (p > 0.05)   |
|---:|:-------------------|:--------------|-------------------------:|----------:|:---------------------------------|
|  0 | Halmstad flygplats | TEMPERATUR    |                  0.9641  |   0.03779 | No                               |
|  1 | Uppsala Flygplats  | TEMPERATUR    |                  0.94367 |   0.00291 | No                               |
|  2 | Umeå Flygplats     | TEMPERATUR    |                  0.92035 |   0.00022 | No                               |
|  3 | Halmstad flygplats | LUFTFUKTIGHET |                  0.88416 |   1e-05   | No                               |
|  4 | Uppsala Flygplats  | LUFTFUKTIGHET |                  0.91839 |   0.00018 | No                               |
|  5 | Umeå Flygplats     | LUFTFUKTIGHET |                  0.96868 |   0.06953 | Yes                              |