|                                         |   count |   mean |   std |   min |    25% |    50% |   75% |   max |
|:----------------------------------------|--------:|-------:|------:|------:|-------:|-------:|------:|------:|
| ('Halmstad flygplats', 'LUFTFUKTIGHET') |      72 |  91.47 |  5.98 |  75   |  90    |  93    | 96    |  99   |
| ('Halmstad flygplats', 'TEMPERATUR')    |      72 |   6.91 |  0.93 |   4.4 |   6.38 |   7    |  7.43 |   8.9 |
| ('Umeå Flygplats', 'LUFTFUKTIGHET')     |      72 |  88.38 |  4.1  |  81   |  85    |  88    | 91.25 |  96   |
| ('Umeå Flygplats', 'TEMPERATUR')        |      72 | -10.61 |  5.68 | -20.4 | -15.82 | -10.05 | -5.38 |  -1.3 |
| ('Uppsala Flygplats', 'LUFTFUKTIGHET')  |      72 |  78.01 | 14.14 |  57   |  64    |  77.5  | 87.25 | 100   |
| ('Uppsala Flygplats', 'TEMPERATUR')     |      72 |   1.27 |  2.48 |  -4.7 |   0.18 |   1.9  |  2.72 |   6.6 |